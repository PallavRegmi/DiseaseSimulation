package Disease;

/**
 * Possible layout types.
 *
 */
public enum LayoutType {
    GRID,
    RANDOM,
    RANDOMGRID;
}